#!/bin/sh

OUTPUT=7376_07.zip

# Remove any previous archive of the project.
rm -f "$OUTPUT"

# Archive the project, excluding hidden files and commercial library files.
zip -r --exclude='*/.*' --exclude='*OpenCVForUnity*' --exclude='*opencvforunity*' "$OUTPUT" *.sh Rollingball